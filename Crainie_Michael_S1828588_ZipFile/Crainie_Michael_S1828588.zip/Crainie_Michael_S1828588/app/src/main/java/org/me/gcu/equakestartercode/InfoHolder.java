//Crainie_Michael_S1828588
package org.me.gcu.equakestartercode;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Date;

    public class InfoHolder {
    public static ArrayList<String> itemTitles = new ArrayList<String>();
    public static ArrayList<String> itemDescriptions = new ArrayList<String>();
    public static ArrayList<String> itemLatitude = new ArrayList<String>();
    public static ArrayList<String> itemLongitude = new ArrayList<String>();
    public static ArrayList<String> itemFullInfo = new ArrayList<String>();
    public static ArrayList<String> itemMagnitude = new ArrayList<String>();
    public static ArrayList<Float>  itemMagFloat = new ArrayList<Float>();
    public static ArrayList<String>  itemCleanString = new ArrayList<String>();
    public static ArrayList<String>  itemLink = new ArrayList<String>();
    public static ArrayList<Date> itemRefinedDate = new ArrayList<Date>();

}
